var icd10Codes;
function applyAutoCompletion(autoCompleteField) {
	// Note - if there are more fields on the form with auto-complete enabled,
	// modify this script to update them all
	
	//icd10Codes = getCodes("0016");
	//console.log("Code" + icd10Codes);
	$( ".auto-complete-demo-control input" ).autocomplete({source: fetchCodes,
		close: function(event, ui) {
			autoCompleteField.value = event.target.value;
		}
	});
	
}

function fetchCodes(request, responseCallback) {
	if (request.term.length > 3)
		getCodes(request.term, responseCallback);
}

// find code with the specific code and return its description
function findCodeDescription(code) {
	const el = icd10Codes ? icd10Codes.find(element => element.code == code) : null;
	return el ? el.description : "";
}

function getCodes(code, responseCallback){
	console.log('Getting code info via rest: ' + code);
	
	var bpmURL = 'http://18.211.133.84:8080';  
	var restURI = '/getcodedescription';
	var postData = '{\"codeType\":\"string\",\"code\":\"' + code + '\"}';
	
	
	var callURL = bpmURL + restURI;
	
	$.ajax({
		  type: "POST",
		  url: callURL,
		  data: postData,
		  success: function(data){
				  	icd10Codes = data;
				  	responseCallback(icd10Codes ? icd10Codes.map(code => {
				  			return {"label": "(" + code.code + ") " + code.description, "value": code.code}
				  		}) : []
				  	);
		  },
		  dataType: 'json',
		  beforeSend: function (xhr) {
			    xhr.setRequestHeader('Content-Type', 'application/json');
			    xhr.setRequestHeader('Accept', 'application/json');
			},
		});
}


//test codes. In realtime, fetchCodes() will need to fetch it from the server 
/*icd10Codes = [
    {
        "description": "Bypass Cerebral Ventricle to Mastoid Sinus with Autologous Tissue Substitute, Open Approach",
        "code": "0016071"
    },
    {
        "description": "Bypass Cerebral Ventricle to Atrium with Autologous Tissue Substitute, Open Approach",
        "code": "0016072"
    },
    {
        "description": "Bypass Cerebral Ventricle to Blood Vessel with Autologous Tissue Substitute, Open Approach",
        "code": "0016073"
    },
    {
        "description": "Bypass Cerebral Ventricle to Pleural Cavity with Autologous Tissue Substitute, Open Approach",
        "code": "0016074"
    },
    {
        "description": "Bypass Cerebral Ventricle to Intestine with Autologous Tissue Substitute, Open Approach",
        "code": "0016075"
    },
    {
        "description": "Bypass Cerebral Ventricle to Peritoneal Cavity with Autologous Tissue Substitute, Open Approach",
        "code": "0016076"
    },
    {
        "description": "Bypass Cerebral Ventricle to Urinary Tract with Autologous Tissue Substitute, Open Approach",
        "code": "0016077"
    },
    {
        "description": "Bypass Cerebral Ventricle to Bone Marrow with Autologous Tissue Substitute, Open Approach",
        "code": "0016078"
    },
    {
        "description": "Bypass Cerebral Ventricle to Subgaleal Space with Autologous Tissue Substitute, Open Approach",
        "code": "001607A"
    },
    {
        "description": "Bypass Cerebral Ventricle to Cerebral Cisterns with Autologous Tissue Substitute, Open Approach",
        "code": "001607B"
    },
    {
        "description": "Bypass Cerebral Ventricle to Nasopharynx with Synthetic Substitute, Open Approach",
        "code": "00160J0"
    },
    {
        "description": "Bypass Cerebral Ventricle to Mastoid Sinus with Synthetic Substitute, Open Approach",
        "code": "00160J1"
    },
    {
        "description": "Bypass Cerebral Ventricle to Atrium with Synthetic Substitute, Open Approach",
        "code": "00160J2"
    },
    {
        "description": "Bypass Cerebral Ventricle to Blood Vessel with Synthetic Substitute, Open Approach",
        "code": "00160J3"
    },
    {
        "description": "Bypass Cerebral Ventricle to Pleural Cavity with Synthetic Substitute, Open Approach",
        "code": "00160J4"
    },
    {
        "description": "Bypass Cerebral Ventricle to Intestine with Synthetic Substitute, Open Approach",
        "code": "00160J5"
    },
    {
        "description": "Bypass Cerebral Ventricle to Peritoneal Cavity with Synthetic Substitute, Open Approach",
        "code": "00160J6"
    },
    {
        "description": "Bypass Cerebral Ventricle to Urinary Tract with Synthetic Substitute, Open Approach",
        "code": "00160J7"
    },
    {
        "description": "Bypass Cerebral Ventricle to Bone Marrow with Synthetic Substitute, Open Approach",
        "code": "00160J8"
    },
    {
        "description": "Bypass Cerebral Ventricle to Subgaleal Space with Synthetic Substitute, Open Approach",
        "code": "00160JA"
    },
    {
        "description": "Bypass Cerebral Ventricle to Cerebral Cisterns with Synthetic Substitute, Open Approach",
        "code": "00160JB"
    },
    {
        "description": "Bypass Cerebral Ventricle to Nasopharynx with Nonautologous Tissue Substitute, Open Approach",
        "code": "00160K0"
    },
    {
        "description": "Bypass Cerebral Ventricle to Mastoid Sinus with Nonautologous Tissue Substitute, Open Approach",
        "code": "00160K1"
    },
    {
        "description": "Bypass Cerebral Ventricle to Atrium with Nonautologous Tissue Substitute, Open Approach",
        "code": "00160K2"
    },
    {
        "description": "Bypass Cerebral Ventricle to Blood Vessel with Nonautologous Tissue Substitute, Open Approach",
        "code": "00160K3"
    },
    {
        "description": "Bypass Cerebral Ventricle to Pleural Cavity with Nonautologous Tissue Substitute, Open Approach",
        "code": "00160K4"
    },
    {
        "description": "Bypass Cerebral Ventricle to Intestine with Nonautologous Tissue Substitute, Open Approach",
        "code": "00160K5"
    },
    {
        "description": "Bypass Cerebral Ventricle to Peritoneal Cavity with Nonautologous Tissue Substitute, Open Approach",
        "code": "00160K6"
    },
    {
        "description": "Bypass Cerebral Ventricle to Urinary Tract with Nonautologous Tissue Substitute, Open Approach",
        "code": "00160K7"
    },
    {
        "description": "Bypass Cerebral Ventricle to Bone Marrow with Nonautologous Tissue Substitute, Open Approach",
        "code": "00160K8"
    },
    {
        "description": "Bypass Cerebral Ventricle to Subgaleal Space with Nonautologous Tissue Substitute, Open Approach",
        "code": "00160KA"
    },
    {
        "description": "Bypass Cerebral Ventricle to Cerebral Cisterns with Nonautologous Tissue Substitute, Open Approach",
        "code": "00160KB"
    },
    {
        "description": "Bypass Cerebral Ventricle to Cerebral Cisterns, Open Approach",
        "code": "00160ZB"
    },
    {
        "description": "Bypass Cerebral Ventricle to Nasopharynx with Autologous Tissue Substitute, Percutaneous Approach",
        "code": "0016370"
    },
    {
        "description": "Bypass Cerebral Ventricle to Mastoid Sinus with Autologous Tissue Substitute, Percutaneous Approach",
        "code": "0016371"
    },
    {
        "description": "Bypass Cerebral Ventricle to Atrium with Autologous Tissue Substitute, Percutaneous Approach",
        "code": "0016372"
    },
    {
        "description": "Bypass Cerebral Ventricle to Blood Vessel with Autologous Tissue Substitute, Percutaneous Approach",
        "code": "0016373"
    },
    {
        "description": "Bypass Cerebral Ventricle to Pleural Cavity with Autologous Tissue Substitute, Percutaneous Approach",
        "code": "0016374"
    },
    {
        "description": "Bypass Cerebral Ventricle to Intestine with Autologous Tissue Substitute, Percutaneous Approach",
        "code": "0016375"
    },
    {
        "description": "Bypass Cerebral Ventricle to Peritoneal Cavity with Autologous Tissue Substitute, Percutaneous Approach",
        "code": "0016376"
    },
    {
        "description": "Bypass Cerebral Ventricle to Urinary Tract with Autologous Tissue Substitute, Percutaneous Approach",
        "code": "0016377"
    },
    {
        "description": "Bypass Cerebral Ventricle to Bone Marrow with Autologous Tissue Substitute, Percutaneous Approach",
        "code": "0016378"
    },
    {
        "description": "Bypass Cerebral Ventricle to Subgaleal Space with Autologous Tissue Substitute, Percutaneous Approach",
        "code": "001637A"
    },
    {
        "description": "Bypass Cerebral Ventricle to Cerebral Cisterns with Autologous Tissue Substitute, Percutaneous Approach",
        "code": "001637B"
    },
    {
        "description": "Bypass Cerebral Ventricle to Nasopharynx with Synthetic Substitute, Percutaneous Approach",
        "code": "00163J0"
    },
    {
        "description": "Bypass Cerebral Ventricle to Mastoid Sinus with Synthetic Substitute, Percutaneous Approach",
        "code": "00163J1"
    },
    {
        "description": "Bypass Cerebral Ventricle to Atrium with Synthetic Substitute, Percutaneous Approach",
        "code": "00163J2"
    },
    {
        "description": "Bypass Cerebral Ventricle to Blood Vessel with Synthetic Substitute, Percutaneous Approach",
        "code": "00163J3"
    },
    {
        "description": "Bypass Cerebral Ventricle to Pleural Cavity with Synthetic Substitute, Percutaneous Approach",
        "code": "00163J4"
    },
    {
        "description": "Bypass Cerebral Ventricle to Intestine with Synthetic Substitute, Percutaneous Approach",
        "code": "00163J5"
    },
    {
        "description": "Bypass Cerebral Ventricle to Peritoneal Cavity with Synthetic Substitute, Percutaneous Approach",
        "code": "00163J6"
    },
    {
        "description": "Bypass Cerebral Ventricle to Urinary Tract with Synthetic Substitute, Percutaneous Approach",
        "code": "00163J7"
    },
    {
        "description": "Bypass Cerebral Ventricle to Bone Marrow with Synthetic Substitute, Percutaneous Approach",
        "code": "00163J8"
    },
    {
        "description": "Bypass Cerebral Ventricle to Subgaleal Space with Synthetic Substitute, Percutaneous Approach",
        "code": "00163JA"
    },
    {
        "description": "Bypass Cerebral Ventricle to Cerebral Cisterns with Synthetic Substitute, Percutaneous Approach",
        "code": "00163JB"
    },
    {
        "description": "Bypass Cerebral Ventricle to Nasopharynx with Nonautologous Tissue Substitute, Percutaneous Approach",
        "code": "00163K0"
    },
    {
        "description": "Bypass Cerebral Ventricle to Mastoid Sinus with Nonautologous Tissue Substitute, Percutaneous Approach",
        "code": "00163K1"
    },
    {
        "description": "Bypass Cerebral Ventricle to Atrium with Nonautologous Tissue Substitute, Percutaneous Approach",
        "code": "00163K2"
    },
    {
        "description": "Bypass Cerebral Ventricle to Blood Vessel with Nonautologous Tissue Substitute, Percutaneous Approach",
        "code": "00163K3"
    },
    {
        "description": "Bypass Cerebral Ventricle to Pleural Cavity with Nonautologous Tissue Substitute, Percutaneous Approach",
        "code": "00163K4"
    },
    {
        "description": "Bypass Cerebral Ventricle to Intestine with Nonautologous Tissue Substitute, Percutaneous Approach",
        "code": "00163K5"
    },
    {
        "description": "Bypass Cerebral Ventricle to Peritoneal Cavity with Nonautologous Tissue Substitute, Percutaneous Approach",
        "code": "00163K6"
    },
    {
        "description": "Bypass Cerebral Ventricle to Urinary Tract with Nonautologous Tissue Substitute, Percutaneous Approach",
        "code": "00163K7"
    },
    {
        "description": "Bypass Cerebral Ventricle to Bone Marrow with Nonautologous Tissue Substitute, Percutaneous Approach",
        "code": "00163K8"
    },
    {
        "description": "Bypass Cerebral Ventricle to Subgaleal Space with Nonautologous Tissue Substitute, Percutaneous Approach",
        "code": "00163KA"
    },
    {
        "description": "Bypass Cerebral Ventricle to Cerebral Cisterns with Nonautologous Tissue Substitute, Percutaneous Approach",
        "code": "00163KB"
    },
    {
        "description": "Bypass Cerebral Ventricle to Cerebral Cisterns, Percutaneous Approach",
        "code": "00163ZB"
    },
    {
        "description": "Bypass Cerebral Ventricle to Nasopharynx with Autologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "0016470"
    },
    {
        "description": "Bypass Cerebral Ventricle to Mastoid Sinus with Autologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "0016471"
    },
    {
        "description": "Bypass Cerebral Ventricle to Atrium with Autologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "0016472"
    },
    {
        "description": "Bypass Cerebral Ventricle to Blood Vessel with Autologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "0016473"
    },
    {
        "description": "Bypass Cerebral Ventricle to Pleural Cavity with Autologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "0016474"
    },
    {
        "description": "Bypass Cerebral Ventricle to Intestine with Autologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "0016475"
    },
    {
        "description": "Bypass Cerebral Ventricle to Peritoneal Cavity with Autologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "0016476"
    },
    {
        "description": "Bypass Cerebral Ventricle to Urinary Tract with Autologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "0016477"
    },
    {
        "description": "Bypass Cerebral Ventricle to Bone Marrow with Autologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "0016478"
    },
    {
        "description": "Bypass Cerebral Ventricle to Subgaleal Space with Autologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "001647A"
    },
    {
        "description": "Bypass Cerebral Ventricle to Cerebral Cisterns with Autologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "001647B"
    },
    {
        "description": "Bypass Cerebral Ventricle to Nasopharynx with Synthetic Substitute, Percutaneous Endoscopic Approach",
        "code": "00164J0"
    },
    {
        "description": "Bypass Cerebral Ventricle to Mastoid Sinus with Synthetic Substitute, Percutaneous Endoscopic Approach",
        "code": "00164J1"
    },
    {
        "description": "Bypass Cerebral Ventricle to Atrium with Synthetic Substitute, Percutaneous Endoscopic Approach",
        "code": "00164J2"
    },
    {
        "description": "Bypass Cerebral Ventricle to Blood Vessel with Synthetic Substitute, Percutaneous Endoscopic Approach",
        "code": "00164J3"
    },
    {
        "description": "Bypass Cerebral Ventricle to Pleural Cavity with Synthetic Substitute, Percutaneous Endoscopic Approach",
        "code": "00164J4"
    },
    {
        "description": "Bypass Cerebral Ventricle to Intestine with Synthetic Substitute, Percutaneous Endoscopic Approach",
        "code": "00164J5"
    },
    {
        "description": "Bypass Cerebral Ventricle to Peritoneal Cavity with Synthetic Substitute, Percutaneous Endoscopic Approach",
        "code": "00164J6"
    },
    {
        "description": "Bypass Cerebral Ventricle to Urinary Tract with Synthetic Substitute, Percutaneous Endoscopic Approach",
        "code": "00164J7"
    },
    {
        "description": "Bypass Cerebral Ventricle to Bone Marrow with Synthetic Substitute, Percutaneous Endoscopic Approach",
        "code": "00164J8"
    },
    {
        "description": "Bypass Cerebral Ventricle to Subgaleal Space with Synthetic Substitute, Percutaneous Endoscopic Approach",
        "code": "00164JA"
    },
    {
        "description": "Bypass Cerebral Ventricle to Cerebral Cisterns with Synthetic Substitute, Percutaneous Endoscopic Approach",
        "code": "00164JB"
    },
    {
        "description": "Bypass Cerebral Ventricle to Nasopharynx with Nonautologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "00164K0"
    },
    {
        "description": "Bypass Cerebral Ventricle to Mastoid Sinus with Nonautologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "00164K1"
    },
    {
        "description": "Bypass Cerebral Ventricle to Atrium with Nonautologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "00164K2"
    },
    {
        "description": "Bypass Cerebral Ventricle to Blood Vessel with Nonautologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "00164K3"
    },
    {
        "description": "Bypass Cerebral Ventricle to Pleural Cavity with Nonautologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "00164K4"
    },
    {
        "description": "Bypass Cerebral Ventricle to Intestine with Nonautologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "00164K5"
    },
    {
        "description": "Bypass Cerebral Ventricle to Peritoneal Cavity with Nonautologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "00164K6"
    },
    {
        "description": "Bypass Cerebral Ventricle to Urinary Tract with Nonautologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "00164K7"
    },
    {
        "description": "Bypass Cerebral Ventricle to Bone Marrow with Nonautologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "00164K8"
    },
    {
        "description": "Bypass Cerebral Ventricle to Subgaleal Space with Nonautologous Tissue Substitute, Percutaneous Endoscopic Approach",
        "code": "00164KA"
    }
];*/

